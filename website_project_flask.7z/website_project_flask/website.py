#imports variable app from our package app. allows script to run and create the website
from app import app


